# Taller de fundamentos: de una tostada a un constructor

Este taller reúne los retos básicos de TypeScript para practicar lógica de programación antes de pasar a React.

La idea no es solamente que el programa funcione. En cada ejercicio se explica qué problema se está resolviendo, cómo se pensó la solución, cómo se prueba y qué ocurre en un caso límite.

## Estructura

- `reto-00-hola-programa.ts`
- `reto-01-conversor-temperatura.ts`
- `reto-02-mayor-de-dos.ts`
- `reto-03-entrada-valida.ts`
- `reto-04-par-o-impar.ts`
- `reto-05-tabla-multiplicar.ts`
- `reto-06-contador-vocales.ts`
- `reto-07-suma-acumulada.ts`
- `reto-08-fizzbuzz.ts`
- `reto-09-promedio-aproximacion.ts`
- `reto-10-mayor-de-una-lista.ts`
- `reto-11-contar-positivos.ts`
- `reto-12-factorial-seguro.ts`
- `reto-13-contrasena-valida.ts`

## Cómo revisar cada reto

Cada archivo contiene:

1. Descripción breve del problema.
2. Función que resuelve el reto.
3. Dos ejemplos de prueba.
4. Explicación de la estrategia.
5. Un caso límite o mejora.
6. Comentarios dentro del código para entender qué hace cada línea importante.

## Orden recomendado

Primero realizar los retos 0 al 8. Después continuar con los retos 9 al 13.

Los archivos están pensados para poder reutilizar las funciones posteriormente dentro de componentes React.

## Nota

Los ejercicios están escritos de forma sencilla para que el objetivo principal sea entender la lógica y no complicar innecesariamente las soluciones.
